package lethalhabit;

public interface Tickable {
    void tick(Double timeDelta);
}
