package lethalhabit.game;

import lethalhabit.technical.Hitbox;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public final class Liquid {

    public static final Map<Integer, Liquid> TILEMAP = new HashMap<>();

    public static void loadLiquids() {
        for (int i = 0; ; i++) {
            try {
                // TODO: read data about liquid (especially viscosity, hitbox) from liquids.json
                InputStream stream = Tile.class.getResourceAsStream("/liquids/liquid" + i + ".png");
                if (stream == null) {
                    System.out.println("Last tile Liquids: " + i);
                    break;
                }
                BufferedImage graphic = ImageIO.read(stream);
                TILEMAP.put(i, new Liquid(0.5, Hitbox.HITBOX_1x1, graphic));
            } catch (IOException ex) {
                break;
            }
        }
    }

    public final double viscosity;
    public final Hitbox hitbox;
    public final BufferedImage graphic;

    public Liquid(double viscosity, Hitbox hitbox, BufferedImage graphic) {
        this.viscosity = viscosity;
        this.hitbox = hitbox;
        this.graphic = graphic;
    }

}
