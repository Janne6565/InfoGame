package lethalhabit.game;

import lethalhabit.Main;
import lethalhabit.technical.Hitbox;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public final class Block {

    public static final Map<Integer, Block> TILEMAP = new HashMap<>();

    public static void loadBlocks() {
        for (int i = 0; ; i++) {
            try {
                // TODO: read data about block (especially hitbox) from tiles.json
                InputStream stream = Tile.class.getResourceAsStream("/tiles/tile" + i + ".png");
                if (stream == null) {
                    break;
                }
                BufferedImage graphic = ImageIO.read(stream );
                TILEMAP.put(i, new Block(Hitbox.HITBOX_1x1, graphic));
            } catch (IOException ex) {
                System.out.println("Last tile Block: " + i);
                break;
            }
        }
    }

    public final Hitbox hitbox;
    public final BufferedImage graphic;

    public Block(Hitbox hitbox, BufferedImage graphic) {
        this.hitbox = hitbox;
        this.graphic = graphic;
    }

}
