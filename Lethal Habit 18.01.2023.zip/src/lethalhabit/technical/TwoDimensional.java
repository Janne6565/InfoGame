package lethalhabit.technical;

public interface TwoDimensional {
    double x();
    double y();
}
