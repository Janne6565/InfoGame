package lethalhabit.technical;

public interface Loadable {
    void load();
}
